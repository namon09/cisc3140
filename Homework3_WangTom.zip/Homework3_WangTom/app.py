# Tom Wang. 9/13/2019. CISC 3140 Homework #3.
# The following program use an API endpoint, reads the file, and gathers its data from Json.
# The program will then run on the local machine using the data from Json and place them onto an HTML file. 
import urllib.request
import json
from flask import Flask
from flask import render_template

app = Flask(__name__)

url = 'https://api.jikan.moe/v3/search/anime?q=Boku%20no%20Hero%Academia&limit=1' #The API endpoint that is used.

urlobj = urllib.request.urlopen(url)
read = urlobj.read()
data = json.loads(read.decode('utf-8'))

print(data) #display data onto output

@app.route('/')
def index():
    title = data["results"][0]["title"] #get title name from json.
    episodes = data["results"][0]["episodes"] #get number of episodes from json.
    rated = data["results"][0]["rated"] #get the television rate from json.
    image = data["results"][0]["image_url"] #get the image from json.
    members = data["results"][0]["members"] #get the number of members(fans) from json.
    score = data["results"][0]["score"] #get the score(out of 10) from json.
    synopsis = data["results"][0]["synopsis"] #get the synopsis(incomplete) from json.

    #return the data from the variables onto the html file.
    return render_template('animeReview.html', title=title, episodes=episodes, rated=rated, image=image, members=members, score=score, synopsis=synopsis) 

if __name__ == "__main__":
    app.run()
