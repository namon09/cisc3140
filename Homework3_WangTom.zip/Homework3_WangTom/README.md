# Guide to running my program
This is a guide on how to start running the program on your local machine.
**Step 1:** Open your terminal and reach to this folder (which is **Homework3_WangTom**)
**Step 2:** Type in **py -m venv env** in the commnd line to create an environment.
**Step 3:** Type in **env\Scripts\activate** to activate the environment.
**Step 4:** Type in **pip install Flask** to install Flask.
**Step 5:** Type in **set FLASK_APP=app.py** and then **flask run** to run the program
**Step 6:** Open the server given from the terminal (**Example:** http://127.0.0.1:5000/) and it will show you the HTML file using data from Json.

**Student Name:** Tom Wang
